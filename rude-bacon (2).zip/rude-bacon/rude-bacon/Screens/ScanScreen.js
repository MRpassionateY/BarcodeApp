import react from 'react';
import { Text, Veiw, TouchableOpacity, Image, StyleSheet } from 'react-native';
import * as Permissions from 'expo-permissions';
import { BarCodeScanner } from 'expo-barcode-scanner';
import React from 'react';


export default class ScanScreen extends React.Component {
    constructor(){
        super();
        this.state = {
            hasCameraPermissions: null,
            scanned: false,
            scannedData: '',
            buttonState: 'normal'        }
    }
}
   if (buttonState === "clicked" && getCameraPermissions){
       return (
           <BarCodeScanner
           onBarCodeScanned={scanned ? undfined : this.handleBarCodeScanned}
           style={StyleSheet.absoluteFillObject}
           />
     
       );
   }

       else if (buttonState === "clicked"){
           return(
               <Veiw style={StyleSheet.container}>
                   <Text style={styles.container}>{
                       getCameraPermissions===true ? this.state.scannedData: "Scan The Code"
                   }
                   </Text>
                   
               </Veiw>
           )
       }

           
       
       

    
           
   
